const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");
const path = require("path");
const bcrypt = require("bcryptjs");

const app = express();

app.use(bodyParser.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

mongoose.connect('mongodb+srv://teamvoyage:TeamVoyage@cluster0.fkpx9.mongodb.net/voyage-db?retryWrites=true&w=majority&appName=Cluster0')
    .then(() => console.log("MongoDB connected successfully"))
    .catch((error) => console.error("MongoDB connection error:", error));

const userSchema = new mongoose.Schema({
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
}, { collection: 'login-db' });  

const User = mongoose.model('User', userSchema);

app.get("/", (req, res) => {
    res.sendFile(path.join(__dirname, "/public/index.html"));
});

app.post("/signup", async (req, res) => {
    const { name, email, password } = req.body;

    try {
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).send("Email already exists.");
        }

        const hashedPassword = await bcrypt.hash(password, 10);

        const newUser = new User({
            name,
            email,
            password: hashedPassword,
        });

        await newUser.save();

        console.log("User registered successfully!");
        res.redirect('index.html');
    } catch (error) {
        console.error("Error during signup:", error);
        res.status(500).send("Error registering user. Please try again.");
    }
});

app.post("/login", async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.status(400).send("Invalid email or password.");
        }

        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(400).send("Invalid email or password.");
        }

        console.log("User logged in successfully!");
        res.redirect('index.html');
    } catch (error) {
        console.error("Error during login:", error);
        res.status(500).send("Error logging in. Please try again.");
    }
});

const port = 8001;
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});