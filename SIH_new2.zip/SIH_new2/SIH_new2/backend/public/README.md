# voyage
This is individual project called Roaming Routes project made by ByteSphere.
[Voyage Website]

## Some of the Features
* search city
* suggest cities (most searched)
* login/signup
* cart (Journey Mapper)
* checkout

## Languages Used
* HTML
* CSS
* JS
